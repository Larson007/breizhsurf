import $ from 'jquery';
import owlCarousel from 'owl.carousel';
import leaflet from 'leaflet';
import 'bootstrap';

$(document).ready(function() {

  // Carousel
  $(".carousel-news").owlCarousel({
    loop: true,
    margin: 30,
    nav: true,
    navText: ['<i class="fa fa-angle-left fa-3x" aria-hidden="true"></i>', '<i class="fa fa-angle-right fa-3x" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      768: {
        items: 2
      },
      992: {
        items: 3
      }
    }
  });

  // MAP
  if ($('#spotMap').length) {

    const themeURL = WPURLS.themeURL;

    const mapDiv = $('#spotMap');
    const lat = mapDiv.data('lat');
    const lon = mapDiv.data('lon');
    const title = mapDiv.data('title');

    const map = L.map('spotMap', {
      center: [lat, lon],
      zoom: 12,
      scrollWheelZoom: false
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const bsIcon = L.icon({
      iconUrl: themeURL + '/dist/images/marker.png',
      shadowUrl: themeURL + '/dist/images/marker-shadow.png',

      iconSize: [38, 90], // size of the icon
      shadowSize: [50, 60], // size of the shadow
      iconAnchor: [22, 90], // point of the icon which will correspond to marker's location
      shadowAnchor: [4, 62], // the same for the shadow
      popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
    });

    L.marker([lat, lon], {
        icon: bsIcon
      }).addTo(map)
      .bindPopup('<h4>' + title + '</h4>')
      .openPopup();
  }


});